const ham = document.querySelector(".hamburger")
const nav = document.querySelector(".nav-links")
const links = document.querySelector(".social-links")

ham.addEventListener("click",()=>{
    nav.classList.toggle('active')
})

links.addEventListener("click",()=>{
    alert("Links Are Not Provided At This Time")
})